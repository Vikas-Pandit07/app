import { useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import type { CartStore } from '../lib/cartStore';
import { formatPrice } from '../lib/data';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, Truck, X } from '../lib/icons';

const FREE_SHIPPING_THRESHOLD = 999;

interface CartDrawerProps {
  cart: CartStore;
}

export default function CartDrawer({ cart }: CartDrawerProps) {
  const navigate = useNavigate();
  const { isDrawerOpen, closeDrawer } = cart;

  // Lock body scroll while the drawer is open, and let Escape close it.
  useEffect(() => {
    if (!isDrawerOpen) return;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeDrawer();
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isDrawerOpen, closeDrawer]);

  const shippingRemaining = Math.max(FREE_SHIPPING_THRESHOLD - cart.subtotal, 0);
  const shippingProgress = Math.min((cart.subtotal / FREE_SHIPPING_THRESHOLD) * 100, 100);

  const handleCheckout = () => {
    closeDrawer();
    navigate('/checkout');
  };

  return (
    <AnimatePresence>
      {isDrawerOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={closeDrawer}
            className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm"
            aria-hidden="true"
          />

          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            role="dialog"
            aria-modal="true"
            aria-label="Shopping cart"
            className="fixed top-0 right-0 z-[61] h-full w-full sm:w-[420px] bg-bg-primary shadow-2xl flex flex-col"
          >
            <div className="flex items-center justify-between px-5 sm:px-6 h-16 border-b border-border-subtle shrink-0">
              <h2 className="font-display text-lg font-bold uppercase tracking-wide">
                Your Cart {cart.totalItems > 0 && <span className="text-text-muted font-normal">({cart.totalItems})</span>}
              </h2>
              <button
                onClick={closeDrawer}
                className="p-2 -mr-2 text-text-secondary hover:text-text-primary transition-colors"
                aria-label="Close cart"
              >
                <X size={20} />
              </button>
            </div>

            {cart.items.length > 0 && (
              <div className="px-5 sm:px-6 py-3 border-b border-border-subtle shrink-0">
                {shippingRemaining > 0 ? (
                  <p className="text-xs text-text-secondary mb-2 flex items-center gap-1.5">
                    <Truck size={14} className="text-[#090909] shrink-0" />
                    Add <span className="font-semibold text-text-primary">{formatPrice(shippingRemaining)}</span> more for free shipping
                  </p>
                ) : (
                  <p className="text-xs text-text-secondary mb-2 flex items-center gap-1.5">
                    <Truck size={14} className="text-[#090909] shrink-0" />
                    <span className="font-semibold text-text-primary">You've unlocked free shipping</span>
                  </p>
                )}
                <div className="h-1 bg-bg-tertiary rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-[#090909] rounded-full"
                    initial={false}
                    animate={{ width: `${shippingProgress}%` }}
                    transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                  />
                </div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto px-5 sm:px-6">
              {cart.items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-16">
                  <div className="w-16 h-16 bg-bg-secondary rounded-full flex items-center justify-center mb-5">
                    <ShoppingBag size={26} className="text-[#090909]" />
                  </div>
                  <p className="font-semibold text-text-primary mb-1">Your cart is empty</p>
                  <p className="text-sm text-text-muted mb-6">Add something you'll love.</p>
                  <button
                    onClick={closeDrawer}
                    className="text-sm font-semibold uppercase tracking-wider text-[#090909] hover:text-[#242424] transition-colors"
                  >
                    Continue Shopping
                  </button>
                </div>
              ) : (
                <ul className="divide-y divide-border-subtle">
                  <AnimatePresence initial={false}>
                    {cart.items.map((item) => (
                      <motion.li
                        key={`${item.product.id}-${item.size}-${item.color}-${item.backendItemId || 'guest'}`}
                        layout
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25 }}
                        className="flex gap-3 py-4"
                      >
                        <Link
                          to={`/product/${item.product.id}`}
                          onClick={closeDrawer}
                          className="w-20 h-20 bg-bg-tertiary rounded-md overflow-hidden shrink-0"
                        >
                          <img
                            src={item.product.images[0]}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = '/placeholder-product.svg';
                            }}
                          />
                        </Link>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <Link to={`/product/${item.product.id}`} onClick={closeDrawer} className="min-w-0">
                              <p className="text-sm font-medium text-text-primary truncate hover:text-[#090909] transition-colors">
                                {item.product.name}
                              </p>
                            </Link>
                            <button
                              onClick={() => void cart.removeItem(item.product.id, item.size, item.color, item.backendItemId)}
                              className="text-text-muted hover:text-[#ef4444] transition-colors p-1 shrink-0"
                              aria-label="Remove item"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                          <p className="text-xs text-text-muted mt-0.5">{item.color} / {item.size}</p>

                          <div className="flex items-center justify-between mt-2.5">
                            <div className="flex items-center border border-text-primary/15 rounded">
                              <button
                                onClick={() =>
                                  void cart.updateQuantity(item.product.id, item.size, item.color, item.quantity - 1, item.backendItemId)
                                }
                                className="p-1.5 text-text-secondary hover:text-text-primary hover:bg-text-primary/5 transition-colors"
                                aria-label="Decrease quantity"
                              >
                                <Minus size={12} />
                              </button>
                              <span className="w-6 text-center text-xs font-medium">{item.quantity}</span>
                              <button
                                onClick={() =>
                                  void cart.updateQuantity(item.product.id, item.size, item.color, item.quantity + 1, item.backendItemId)
                                }
                                className="p-1.5 text-text-secondary hover:text-text-primary hover:bg-text-primary/5 transition-colors"
                                aria-label="Increase quantity"
                              >
                                <Plus size={12} />
                              </button>
                            </div>
                            <p className="text-sm font-semibold text-text-primary">
                              {formatPrice(item.product.price * item.quantity)}
                            </p>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
              )}
            </div>

            {cart.items.length > 0 && (
              <div className="px-5 sm:px-6 py-5 border-t border-border-subtle shrink-0 space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-text-secondary">Subtotal</span>
                  <span className="font-semibold text-text-primary">{formatPrice(cart.subtotal)}</span>
                </div>
                <button
                  onClick={handleCheckout}
                  className="w-full flex items-center justify-center gap-2 bg-[#090909] hover:bg-[#242424] text-white py-3.5 rounded font-semibold uppercase text-sm tracking-wider transition-colors"
                >
                  Checkout <ArrowRight size={16} />
                </button>
                <Link
                  to="/cart"
                  onClick={closeDrawer}
                  className="block text-center text-xs text-text-muted hover:text-text-primary transition-colors"
                >
                  View full cart
                </Link>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
