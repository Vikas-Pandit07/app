-- ============================================================================
-- V1__baseline_schema.sql
-- Baseline schema for OUTLOOX, generated from the current JPA entity classes
-- (backend/src/main/java/com/outloox/entity/**).
--
-- This is a BASELINE: it captures the schema that Hibernate's ddl-auto=validate
-- already expects today. It does not represent a "history" of past changes --
-- it's the starting line. All future schema changes must ship as new
-- Vn__description.sql files; never edit this file after it has run once
-- against a real database.
--
-- Dialect: MySQL 8 (matches pom.xml: mysql-connector-j + flyway-mysql)
-- ============================================================================

SET NAMES utf8mb4;

-- ----------------------------------------------------------------------------
-- categories  (Category.java)
-- ----------------------------------------------------------------------------
CREATE TABLE categories (
    category_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    category_name   VARCHAR(100) NOT NULL,
    description     TEXT NULL,
    image_url       VARCHAR(500) NULL,
    display_order   INT NULL DEFAULT 0,
    is_active       BOOLEAN NULL DEFAULT TRUE,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    created_by      BIGINT NULL,
    updated_by      BIGINT NULL,
    deleted_at      DATETIME NULL,
    CONSTRAINT uq_categories_name UNIQUE (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- brands  (Brand.java)
-- ----------------------------------------------------------------------------
CREATE TABLE brands (
    brand_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(120) NOT NULL,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    created_by      BIGINT NULL,
    updated_by      BIGINT NULL,
    deleted_at      DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- users  (User.java)
-- ----------------------------------------------------------------------------
CREATE TABLE users (
    user_id         INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(50) NOT NULL,
    email           VARCHAR(150) NOT NULL,
    password        VARCHAR(255) NOT NULL,
    role            VARCHAR(20) NOT NULL DEFAULT 'CUSTOMER',
    status          VARCHAR(30) NOT NULL DEFAULT 'ACTIVE',
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    first_name      VARCHAR(100) NULL,
    last_name       VARCHAR(100) NULL,
    phone           VARCHAR(20) NULL,
    avatar_url      VARCHAR(500) NULL,
    email_verified  BOOLEAN NULL DEFAULT FALSE,
    phone_verified  BOOLEAN NULL DEFAULT FALSE,
    last_login_at   DATETIME NULL,
    last_login_ip   VARCHAR(45) NULL,
    login_attempts  INT NULL DEFAULT 0,
    locked_until    DATETIME NULL,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    created_by      BIGINT NULL,
    updated_by      BIGINT NULL,
    deleted_at      DATETIME NULL,
    CONSTRAINT uq_users_username UNIQUE (username),
    CONSTRAINT uq_users_email UNIQUE (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- addresses  (Address.java)
-- ----------------------------------------------------------------------------
CREATE TABLE addresses (
    address_id      INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    full_name       VARCHAR(100) NOT NULL,
    phone           VARCHAR(15) NOT NULL,
    address_line    TEXT NOT NULL,
    city            VARCHAR(50) NOT NULL,
    state           VARCHAR(50) NOT NULL,
    pin_code        VARCHAR(10) NOT NULL,
    country         VARCHAR(50) NOT NULL DEFAULT 'India',
    is_default      BOOLEAN NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    CONSTRAINT fk_addresses_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_addresses_user ON addresses (user_id);

-- ----------------------------------------------------------------------------
-- products  (Product.java)
-- ----------------------------------------------------------------------------
CREATE TABLE products (
    product_id          INT AUTO_INCREMENT PRIMARY KEY,
    name                VARCHAR(120) NOT NULL,
    slug                VARCHAR(150) NOT NULL,
    description         TEXT NULL,
    short_description   VARCHAR(500) NULL,
    price               DECIMAL(10,2) NOT NULL,
    original_price      DECIMAL(10,2) NULL,
    stock               INT NOT NULL DEFAULT 0,
    badge               VARCHAR(20) NULL,
    rating              DOUBLE NOT NULL DEFAULT 4.5,
    review_count        INT NOT NULL DEFAULT 0,
    colors_data         TEXT NULL,
    sizes_data          TEXT NULL,
    features_data       TEXT NULL,
    status              VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    view_count          BIGINT NULL DEFAULT 0,
    purchase_count      BIGINT NULL DEFAULT 0,
    category_id         BIGINT NOT NULL,
    brand_id            BIGINT NULL,
    created_at          DATETIME NOT NULL,
    updated_at          DATETIME NOT NULL,
    created_by          BIGINT NULL,
    updated_by          BIGINT NULL,
    deleted_at          DATETIME NULL,
    CONSTRAINT uq_products_slug UNIQUE (slug),
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories (category_id),
    CONSTRAINT fk_products_brand FOREIGN KEY (brand_id) REFERENCES brands (brand_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_products_category ON products (category_id);
CREATE INDEX idx_products_brand ON products (brand_id);
CREATE INDEX idx_products_status ON products (status);

-- ----------------------------------------------------------------------------
-- product_images  (ProductImage.java)
-- ----------------------------------------------------------------------------
CREATE TABLE product_images (
    image_id        INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    image_url       VARCHAR(500) NOT NULL,
    is_primary      BOOLEAN NOT NULL DEFAULT FALSE,
    CONSTRAINT fk_product_images_product FOREIGN KEY (product_id) REFERENCES products (product_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_product_images_product ON product_images (product_id);

-- ----------------------------------------------------------------------------
-- product_variants  (ProductVariant.java)
-- ----------------------------------------------------------------------------
CREATE TABLE product_variants (
    variant_id      INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    sku             VARCHAR(100) NULL,
    CONSTRAINT fk_product_variants_product FOREIGN KEY (product_id) REFERENCES products (product_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_product_variants_product ON product_variants (product_id);

-- ----------------------------------------------------------------------------
-- cart  (Cart.java)
-- ----------------------------------------------------------------------------
CREATE TABLE cart (
    cart_id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NULL,
    CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_cart_user ON cart (user_id);

-- ----------------------------------------------------------------------------
-- cart_items  (CartItem.java)
-- ----------------------------------------------------------------------------
CREATE TABLE cart_items (
    cart_item_id    INT AUTO_INCREMENT PRIMARY KEY,
    cart_id         INT NULL,
    product_id      INT NULL,
    size_option     VARCHAR(50) NULL DEFAULT 'Standard',
    color_option    VARCHAR(50) NULL DEFAULT 'Standard',
    quantity        INT NOT NULL,
    CONSTRAINT fk_cart_items_cart FOREIGN KEY (cart_id) REFERENCES cart (cart_id) ON DELETE CASCADE,
    CONSTRAINT fk_cart_items_product FOREIGN KEY (product_id) REFERENCES products (product_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_cart_items_cart ON cart_items (cart_id);
CREATE INDEX idx_cart_items_product ON cart_items (product_id);

-- ----------------------------------------------------------------------------
-- orders  (Order.java)
-- ----------------------------------------------------------------------------
CREATE TABLE orders (
    order_id            INT AUTO_INCREMENT PRIMARY KEY,
    order_number        VARCHAR(50) NOT NULL,
    user_id             INT NOT NULL,
    total_amount        DECIMAL(10,2) NOT NULL,
    order_status        VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    payment_status      VARCHAR(30) NOT NULL DEFAULT 'PENDING',
    order_date          DATETIME NOT NULL,
    address_id          INT NULL,
    payment_method      VARCHAR(30) NULL,
    razorpay_order_id   VARCHAR(100) NULL,
    razorpay_payment_id VARCHAR(100) NULL,
    razorpay_signature  VARCHAR(255) NULL,
    shipping_charge     DECIMAL(10,2) NULL DEFAULT 0,
    tax_amount          DECIMAL(10,2) NULL DEFAULT 0,
    discount_amount     DECIMAL(10,2) NULL DEFAULT 0,
    coupon_code         VARCHAR(50) NULL,
    tracking_number     VARCHAR(100) NULL,
    shipping_partner    VARCHAR(100) NULL,
    delivered_at        DATETIME NULL,
    created_at          DATETIME NOT NULL,
    updated_at          DATETIME NOT NULL,
    created_by          BIGINT NULL,
    updated_by          BIGINT NULL,
    deleted_at          DATETIME NULL,
    CONSTRAINT uq_orders_order_number UNIQUE (order_number),
    CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users (user_id),
    CONSTRAINT fk_orders_address FOREIGN KEY (address_id) REFERENCES addresses (address_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_orders_user ON orders (user_id);
CREATE INDEX idx_orders_status ON orders (order_status);
CREATE INDEX idx_orders_payment_status ON orders (payment_status);

-- ----------------------------------------------------------------------------
-- order_items  (OrderItem.java)
-- ----------------------------------------------------------------------------
CREATE TABLE order_items (
    order_item_id   INT AUTO_INCREMENT PRIMARY KEY,
    order_id        INT NULL,
    product_id      INT NULL,
    size_option     VARCHAR(50) NULL DEFAULT 'Standard',
    color_option    VARCHAR(50) NULL DEFAULT 'Standard',
    quantity        INT NULL,
    price           DECIMAL(19,2) NULL,
    total_price     DECIMAL(19,2) NULL,
    CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders (order_id) ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_order_items_order ON order_items (order_id);
CREATE INDEX idx_order_items_product ON order_items (product_id);

-- ----------------------------------------------------------------------------
-- refresh_tokens  (RefreshToken.java)
-- ----------------------------------------------------------------------------
CREATE TABLE refresh_tokens (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    token           VARCHAR(512) NOT NULL,
    device_info     VARCHAR(255) NULL,
    ip_address      VARCHAR(45) NULL,
    expires_at      DATETIME NOT NULL,
    revoked         BOOLEAN NULL DEFAULT FALSE,
    created_at      DATETIME NULL,
    CONSTRAINT uq_refresh_tokens_user UNIQUE (user_id),
    CONSTRAINT uq_refresh_tokens_token UNIQUE (token),
    CONSTRAINT fk_refresh_tokens_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- password_reset_tokens  (PasswordResetToken.java)
-- ----------------------------------------------------------------------------
CREATE TABLE password_reset_tokens (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    token           VARCHAR(255) NOT NULL,
    user_id         INT NOT NULL,
    expiry_date     DATETIME NOT NULL,
    used            BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      DATETIME NULL,
    CONSTRAINT uq_password_reset_tokens_token UNIQUE (token),
    CONSTRAINT uq_password_reset_tokens_user UNIQUE (user_id),
    CONSTRAINT fk_password_reset_tokens_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- wallets  (Wallet.java)
-- ----------------------------------------------------------------------------
CREATE TABLE wallets (
    wallet_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    balance         DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_earned    DECIMAL(10,2) NULL DEFAULT 0,
    total_spent     DECIMAL(10,2) NULL DEFAULT 0,
    is_active       BOOLEAN NULL DEFAULT TRUE,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    created_by      BIGINT NULL,
    updated_by      BIGINT NULL,
    deleted_at      DATETIME NULL,
    CONSTRAINT uq_wallets_user UNIQUE (user_id),
    CONSTRAINT fk_wallets_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- loyalty_points  (LoyaltyPoints.java)
-- ----------------------------------------------------------------------------
CREATE TABLE loyalty_points (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NULL,
    points          INT NULL DEFAULT 0,
    CONSTRAINT uq_loyalty_points_user UNIQUE (user_id),
    CONSTRAINT fk_loyalty_points_user FOREIGN KEY (user_id) REFERENCES users (user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------------------------------------------------------
-- site_settings  (SiteSetting.java)
-- ----------------------------------------------------------------------------
CREATE TABLE site_settings (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    setting_key     VARCHAR(120) NOT NULL,
    setting_value   TEXT NULL,
    updated_at      DATETIME NOT NULL,
    CONSTRAINT uq_site_settings_key UNIQUE (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
