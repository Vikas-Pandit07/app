import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useProducts } from '../context/ProductsContext';
import { formatPrice } from '../lib/data';
import { Search, TrendingUp, X } from '../lib/icons';

const RECENT_SEARCHES_KEY = 'outloox-recent-searches';
const MAX_RECENT = 5;
const MAX_SUGGESTIONS = 5;

function readRecentSearches(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_SEARCHES_KEY);
    return raw ? (JSON.parse(raw) as string[]) : [];
  } catch {
    return [];
  }
}

function writeRecentSearches(searches: string[]) {
  localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(searches));
}

interface SearchBarProps {
  variant?: 'desktop' | 'mobile';
  /** Only one mounted SearchBar should listen for Ctrl/Cmd+K at a time. */
  enableShortcut?: boolean;
  onNavigate?: () => void;
}

export default function SearchBar({ variant = 'desktop', enableShortcut = false, onNavigate }: SearchBarProps) {
  const navigate = useNavigate();
  const { products } = useProducts();
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setRecentSearches(readRecentSearches());
  }, []);

  // Global Ctrl+K / Cmd+K shortcut to jump into the search field.
  useEffect(() => {
    if (!enableShortcut) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      }
      if (e.key === 'Escape') {
        inputRef.current?.blur();
        setIsOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [enableShortcut]);

  // Close the dropdown on outside click.
  useEffect(() => {
    if (!isOpen) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const suggestions = useMemo(() => {
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return [];
    return products
      .filter((product) => product.name.toLowerCase().includes(trimmed) || product.category.toLowerCase().includes(trimmed))
      .slice(0, MAX_SUGGESTIONS);
  }, [query, products]);

  // Popular searches derived from real product data (bestsellers first, then names),
  // rather than a hardcoded list that drifts from the actual catalog.
  const popularSearches = useMemo(() => {
    const bestsellers = products.filter((p) => p.badge === 'bestseller').map((p) => p.name);
    const rest = products.map((p) => p.name).filter((name) => !bestsellers.includes(name));
    return [...bestsellers, ...rest].slice(0, 5);
  }, [products]);

  const commitSearch = (term: string) => {
    const trimmed = term.trim();
    if (!trimmed) return;

    const updated = [trimmed, ...recentSearches.filter((s) => s.toLowerCase() !== trimmed.toLowerCase())].slice(0, MAX_RECENT);
    setRecentSearches(updated);
    writeRecentSearches(updated);

    navigate(`/shop?search=${encodeURIComponent(trimmed)}`);
    setQuery('');
    setIsOpen(false);
    inputRef.current?.blur();
    onNavigate?.();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    commitSearch(query);
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    writeRecentSearches([]);
  };

  const showDropdown = isOpen && (suggestions.length > 0 || recentSearches.length > 0 || popularSearches.length > 0);

  const isMobile = variant === 'mobile';

  return (
    <div ref={containerRef} className={`relative ${isMobile ? 'w-full' : 'hidden md:block'}`}>
      <form onSubmit={handleSubmit} className="flex items-center relative">
        <input
          ref={inputRef}
          type="text"
          placeholder="Search products..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsOpen(true)}
          className={
            isMobile
              ? 'w-full bg-text-primary/5 border border-border-subtle rounded-lg py-2.5 pl-4 pr-16 text-sm text-text-primary placeholder-text-muted focus:border-[#090909] transition-colors'
              : 'w-48 lg:w-64 bg-transparent border border-border-subtle rounded-none py-1.5 pl-3 pr-16 text-sm text-text-primary placeholder-text-muted focus:border-text-primary transition-colors'
          }
        />
        <div className="absolute right-2.5 flex items-center gap-1.5">
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="text-text-muted hover:text-text-primary transition-colors p-0.5"
              aria-label="Clear search"
            >
              <X size={14} />
            </button>
          )}
          {!isMobile && !query && (
            <kbd className="hidden lg:flex items-center gap-0.5 text-[10px] text-text-muted border border-border-subtle rounded px-1.5 py-0.5 font-sans">
              ⌘K
            </kbd>
          )}
          <button type="submit" className="text-text-muted hover:text-text-primary transition-colors" aria-label="Search">
            <Search size={isMobile ? 18 : 16} />
          </button>
        </div>
      </form>

      <AnimatePresence>
        {showDropdown && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.18 }}
            className={`absolute z-50 mt-2 bg-bg-primary border border-border-subtle rounded-lg shadow-xl overflow-hidden ${
              isMobile ? 'left-0 right-0' : 'left-0 w-80'
            }`}
          >
            {suggestions.length > 0 ? (
              <div className="py-2">
                <p className="px-4 pb-1 text-[11px] font-semibold uppercase tracking-wider text-text-muted">Products</p>
                {suggestions.map((product) => (
                  <button
                    key={product.id}
                    onClick={() => {
                      navigate(`/product/${product.id}`);
                      setQuery('');
                      setIsOpen(false);
                      onNavigate?.();
                    }}
                    className="w-full flex items-center gap-3 px-4 py-2 hover:bg-bg-secondary transition-colors text-left"
                  >
                    <div className="w-10 h-10 bg-bg-tertiary rounded overflow-hidden shrink-0">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/placeholder-product.svg';
                        }}
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-text-primary truncate">{product.name}</p>
                      <p className="text-xs text-text-muted">{formatPrice(product.price)}</p>
                    </div>
                  </button>
                ))}
                <button
                  onClick={() => commitSearch(query)}
                  className="w-full px-4 py-2 text-left text-xs font-semibold text-[#090909] hover:bg-bg-secondary transition-colors uppercase tracking-wider"
                >
                  View all results for "{query}"
                </button>
              </div>
            ) : (
              <div className="py-2">
                {recentSearches.length > 0 && (
                  <div className="pb-2">
                    <div className="flex items-center justify-between px-4 pb-1">
                      <p className="text-[11px] font-semibold uppercase tracking-wider text-text-muted">Recent</p>
                      <button onClick={clearRecentSearches} className="text-[11px] text-text-muted hover:text-text-primary transition-colors">
                        Clear
                      </button>
                    </div>
                    {recentSearches.map((term) => (
                      <button
                        key={term}
                        onClick={() => commitSearch(term)}
                        className="w-full flex items-center gap-2.5 px-4 py-1.5 hover:bg-bg-secondary transition-colors text-left text-sm text-text-secondary"
                      >
                        <Search size={13} className="text-text-muted shrink-0" />
                        {term}
                      </button>
                    ))}
                  </div>
                )}
                {popularSearches.length > 0 && (
                  <div className={recentSearches.length > 0 ? 'pt-2 border-t border-border-subtle' : ''}>
                    <p className="px-4 pb-1 text-[11px] font-semibold uppercase tracking-wider text-text-muted">Popular</p>
                    {popularSearches.map((term) => (
                      <button
                        key={term}
                        onClick={() => commitSearch(term)}
                        className="w-full flex items-center gap-2.5 px-4 py-1.5 hover:bg-bg-secondary transition-colors text-left text-sm text-text-secondary"
                      >
                        <TrendingUp size={13} className="text-text-muted shrink-0" />
                        {term}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
